# Loads Island's MediaBridge library inside Apple's perl (which may read Now Playing)
# and runs one of its entry points: island_stream or island_send.
use strict;
use DynaLoader;
my ($path, $entry) = @ARGV;
my $lib = DynaLoader::dl_load_file($path, 0) or die "load failed: " . DynaLoader::dl_error();
my $sym = DynaLoader::dl_find_symbol($lib, $entry) or die "missing $entry";
DynaLoader::dl_install_xsub("main::run", $sym);
main::run();
